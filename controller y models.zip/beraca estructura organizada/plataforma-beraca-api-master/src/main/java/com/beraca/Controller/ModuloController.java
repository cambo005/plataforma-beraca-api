package com.beraca.Controller;

import com.beraca.model.Modulo;
import org.springframework.web.bind.annotation.*;

    @RestController
    @RequestMapping("/modulos")
    public class ModuloController {

        @GetMapping
        public String obtenerModulos() {

            return "Lista de módulos";
        }

        @PostMapping("/crear")
        public Modulo crearModulo(
                @RequestBody Modulo modulo) {

            return modulo;
        }

        @PutMapping("/actualizar")
        public String actualizarModulo(
                @RequestBody Modulo modulo) {

            return "Módulo actualizado";
        }

        @DeleteMapping("/eliminar/{id}")
        public String eliminarModulo(
                @PathVariable Long id) {

            return "Módulo eliminado con ID: " + id;
        }
    }

