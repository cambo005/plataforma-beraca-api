package com.beraca.Controller;

import com.beraca.model.Calificacion;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/estudiante_Modulo")
public class Estudiante_ModuloController {


        @GetMapping
        public String obtenerCalificaciones() {

            return "Lista de calificaciones";
        }

        @PostMapping("/guardar")
        public Calificacion guardarNota(
                @RequestBody Calificacion calificacion) {

            return calificacion;
        }

        @PutMapping("/actualizar")
        public String actualizarNota(
                @RequestBody Calificacion calificacion) {

            return "Calificación actualizada";
        }

        @DeleteMapping("/eliminar/{id}")
        public String eliminarNota(
                @PathVariable Long id) {

            return "Calificación eliminada con ID: " + id;
        }
    }

