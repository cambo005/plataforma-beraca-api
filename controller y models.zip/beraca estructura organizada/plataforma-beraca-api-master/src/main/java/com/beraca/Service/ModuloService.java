package com.beraca.Service;

public class ModuloService {
}
