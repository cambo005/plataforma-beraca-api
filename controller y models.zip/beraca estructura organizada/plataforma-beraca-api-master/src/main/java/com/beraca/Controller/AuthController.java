package com.beraca.Controller;

import com.beraca.model.Usuario;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    // LOGIN
    @PostMapping("/login")
    public String login(@RequestBody Usuario usuario) {

        if(usuario.getRol().equals("profesor")) {

            return "Acceso profesor";

        } else {

            return "Acceso estudiante";
        }
    }

    // GET
    @GetMapping("/usuarios")
    public String obtenerUsuarios() {

        return "Lista de usuarios";
    }

    // PUT
    @PutMapping("/actualizar")
    public String actualizarUsuario(
            @RequestBody Usuario usuario) {

        return "Usuario actualizado";
    }

    // DELETE
    @DeleteMapping("/eliminar/{id}")
    public String eliminarUsuario(
            @PathVariable Long id) {

        return "Usuario eliminado con ID: " + id;
    }
}
