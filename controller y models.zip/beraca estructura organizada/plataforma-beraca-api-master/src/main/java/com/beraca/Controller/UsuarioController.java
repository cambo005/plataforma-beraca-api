package com.beraca.Controller;


import com.beraca.model.Usuario;
import org.springframework.web.bind.annotation.*;

    @RestController
    @RequestMapping("/usuarios")
    public class UsuarioController {

        @GetMapping
        public String obtenerUsuarios() {

            return "Lista de usuarios";
        }

        @PostMapping("/crear")
        public Usuario crearUsuario(
                @RequestBody Usuario usuario) {

            return usuario;
        }

        @PutMapping("/actualizar")
        public String actualizarUsuario(
                @RequestBody Usuario usuario) {

            return "Usuario actualizado";
        }

        @DeleteMapping("/eliminar/{id}")
        public String eliminarUsuario(
                @PathVariable Long id) {

            return "Usuario eliminado con ID: " + id;
        }
    }

