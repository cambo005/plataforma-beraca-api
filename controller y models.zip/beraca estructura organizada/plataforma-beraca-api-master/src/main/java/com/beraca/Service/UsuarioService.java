package com.beraca.Service;

import com.beraca.model.Usuario;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService {

    public Usuario crearUsuario(Usuario usuario){

        return usuario;
    }

}
