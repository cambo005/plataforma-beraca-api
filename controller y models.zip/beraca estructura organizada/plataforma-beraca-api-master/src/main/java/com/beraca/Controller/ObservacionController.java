package com.beraca.Controller;

import com.beraca.model.Observacion;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/observaciones")
public class ObservacionController {

    @GetMapping
    public String obtenerObservaciones() {

        return "Lista de observaciones";
    }

    @PostMapping("/crear")
    public Observacion crearObservacion(
            @RequestBody Observacion observacion) {

        return observacion;
    }

    @PutMapping("/actualizar")
    public String actualizarObservacion(
            @RequestBody Observacion observacion) {

        return "Observación actualizada";
    }

    @DeleteMapping("/eliminar/{id}")
    public String eliminarObservacion(
            @PathVariable Long id) {

        return "Observación eliminada con ID: " + id;
    }
}