package com.beraca.DataEstructure;

import com.beraca.model.Modulo;

import java.util.ArrayList;
import java.util.List;

public class ListaModulo {

    private NodoModulo cabeza;

        // AGREGAR
        public void agregar(Modulo modulo) {

            NodoModulo nuevo = new NodoModulo(modulo);

            if(cabeza == null) {

                cabeza = nuevo;

            } else {

                NodoModulo actual = cabeza;

                while(actual.siguiente != null) {
                    actual = actual.siguiente;
                }

                actual.siguiente = nuevo;
            }
        }

        // LISTAR
        public List<Modulo> listar() {

            List<Modulo> modulos = new ArrayList<>();

            NodoModulo actual = cabeza;

            while(actual != null) {

                modulos.add(actual.modulo);

                actual = actual.siguiente;
            }

            return modulos;
        }

        // BUSCAR POR ID
        public Modulo buscar(Long id) {

            NodoModulo actual = cabeza;

            while(actual != null) {

                if(actual.modulo.getID().equals(id)) {
                    return actual.modulo;
                }

                actual = actual.siguiente;
            }

            return null;
        }

        // ELIMINAR
        public boolean eliminar(Long id) {

            if(cabeza == null) {
                return false;
            }

            if(cabeza.modulo.getID().equals(id)) {
                cabeza = cabeza.siguiente;
                return true;
            }

            NodoModulo actual = cabeza;

            while(actual.siguiente != null) {

                if(actual.siguiente.modulo.getID().equals(id)) {

                    actual.siguiente = actual.siguiente.siguiente;

                    return true;
                }

                actual = actual.siguiente;
            }

            return false;
        }
    }


