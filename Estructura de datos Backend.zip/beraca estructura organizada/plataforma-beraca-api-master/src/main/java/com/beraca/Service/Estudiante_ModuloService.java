package com.beraca.Service;

import com.beraca.DataEstructure.ListaEstudiante_Modulo;
import com.beraca.model.Estudiante_Modulo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Estudiante_ModuloService {

    private ListaEstudiante_Modulo lista =
            new ListaEstudiante_Modulo();

    // POST
    public Estudiante_Modulo guardar(
            Estudiante_Modulo estudiante_Modulo) {

        lista.agregar(estudiante_Modulo);

        return estudiante_Modulo;
    }

    // GET
    public List<Estudiante_Modulo> obtenerTodos() {

        return lista.listar();
    }

    // GET POR ID
    public Estudiante_Modulo buscar(
            Long estudiante_id) {

        return lista.buscar(estudiante_id);
    }

    // DELETE
    public boolean eliminar(
            Long estudiante_id) {

        return lista.eliminar(estudiante_id);
    }
}