package com.beraca.DataEstructure;

import com.beraca.model.Usuario;
import java.util.ArrayList;
import java.util.List;
public class ListaUsuario {


        private NodoUsuario cabeza;

        // AGREGAR
        public void agregar(Usuario usuario) {

            NodoUsuario nuevo = new NodoUsuario(usuario);

            if(cabeza == null) {

                cabeza = nuevo;

            } else {

                NodoUsuario actual = cabeza;

                while(actual.siguiente != null) {
                    actual = actual.siguiente;
                }

                actual.siguiente = nuevo;
            }
        }

        // LISTAR
        public List<Usuario> listar() {

            List<Usuario> usuarios = new ArrayList<>();

            NodoUsuario actual = cabeza;

            while(actual != null) {

                usuarios.add(actual.usuario);

                actual = actual.siguiente;
            }

            return usuarios;
        }

        // BUSCAR POR ID
        public Usuario buscar(Long id) {

            NodoUsuario actual = cabeza;

            while(actual != null) {

                if(actual.usuario.getID().equals(id)) {
                    return actual.usuario;
                }

                actual = actual.siguiente;
            }

            return null;
        }

        // ELIMINAR
        public boolean eliminar(Long id) {

            if(cabeza == null) {
                return false;
            }

            if(cabeza.usuario.getID().equals(id)) {
                cabeza = cabeza.siguiente;
                return true;
            }

            NodoUsuario actual = cabeza;

            while(actual.siguiente != null) {

                if(actual.siguiente.usuario.getID().equals(id)) {

                    actual.siguiente = actual.siguiente.siguiente;

                    return true;
                }

                actual = actual.siguiente;
            }

            return false;
        }
    }

