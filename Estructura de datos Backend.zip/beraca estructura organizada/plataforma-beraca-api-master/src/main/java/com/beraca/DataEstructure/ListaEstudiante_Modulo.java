package com.beraca.DataEstructure;

import com.beraca.model.Estudiante_Modulo;

import java.util.ArrayList;
import java.util.List;

public class ListaEstudiante_Modulo {

    private NodoEstudiante_Modulo cabeza;

    // AGREGAR
    public void agregar(Estudiante_Modulo estudianteModulo) {

        NodoEstudiante_Modulo nuevo =
                new NodoEstudiante_Modulo(estudianteModulo);

        if(cabeza == null) {

            cabeza = nuevo;

        } else {

            NodoEstudiante_Modulo actual = cabeza;

            while(actual.siguiente != null) {

                actual = actual.siguiente;
            }

            actual.siguiente = nuevo;
        }
    }

    // LISTAR
    public List<Estudiante_Modulo> listar() {

        List<Estudiante_Modulo> lista =
                new ArrayList<>();

        NodoEstudiante_Modulo actual = cabeza;

        while(actual != null) {

            lista.add(actual.estudiante_Modulo);

            actual = actual.siguiente;
        }

        return lista;
    }

    // BUSCAR POR estudiante_id
    public Estudiante_Modulo buscar(Long estudiante_id) {

        NodoEstudiante_Modulo actual = cabeza;

        while(actual != null) {

            if(actual.estudiante_Modulo
                    .getEstudiante_id()
                    .equals(estudiante_id)) {

                return actual.estudiante_Modulo;
            }

            actual = actual.siguiente;
        }

        return null;
    }

    // ELIMINAR
    public boolean eliminar(Long estudiante_id) {

        if(cabeza == null) {

            return false;
        }

        if(cabeza.estudiante_Modulo
                .getEstudiante_id()
                .equals(estudiante_id)) {

            cabeza = cabeza.siguiente;

            return true;
        }

        NodoEstudiante_Modulo actual = cabeza;

        while(actual.siguiente != null) {

            if(actual.siguiente.estudiante_Modulo
                    .getEstudiante_id()
                    .equals(estudiante_id)) {

                actual.siguiente =
                        actual.siguiente.siguiente;

                return true;
            }

            actual = actual.siguiente;
        }

        return false;
    }
}
