package com.beraca.Security;

import com.beraca.model.Observacion;
import com.beraca.model.Usuario;

public class SecurityObservacion {

    // VER OBSERVACIONES
    public static boolean puedeVerObservacion(
            Usuario usuario){

        return usuario.getRol()
                .equalsIgnoreCase("profesor")

                ||

                usuario.getRol()
                        .equalsIgnoreCase("estudiante");
    }

    // CREAR OBSERVACIONES
    public static boolean puedeCrearObservacion(
            Usuario usuario){

        return usuario.getRol()
                .equalsIgnoreCase("profesor");
    }

    // ACTUALIZAR OBSERVACIONES
    public static boolean puedeActualizarObservacion(
            Usuario usuario){

        return usuario.getRol()
                .equalsIgnoreCase("profesor");
    }

    // ELIMINAR OBSERVACIONES
    public static boolean puedeEliminarObservacion(
            Usuario usuario){

        return usuario.getRol()
                .equalsIgnoreCase("profesor");
    }

    // VALIDAR DATOS
    public static boolean observacionValida(
            Observacion observacion){

        return observacion.getComentario() != null
                && observacion.getFecha() != null;
    }
}