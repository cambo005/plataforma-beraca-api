package com.beraca.Controller;

import com.beraca.Service.CalificacionService;
import com.beraca.model.Calificacion;
import com.beraca.model.Usuario;
import com.beraca.Security.SecurityCalificacion;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/calificaciones")
public class CalificacionController {

    private final CalificacionService calificacionService;

    public CalificacionController(
            CalificacionService calificacionService) {

        this.calificacionService = calificacionService;
    }

    // POST
    @PostMapping("/crear")
    public Object crearCalificacion(

            @RequestBody Calificacion calificacion,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        // VALIDAR PERMISOS
        if(!SecurityCalificacion
                .puedeCrearCalificacion(usuario)){

            return "Acceso denegado";
        }

        // VALIDAR DATOS
        if(!SecurityCalificacion
                .calificacionValida(calificacion)){

            return "Datos inválidos";
        }

        return calificacionService.guardar(calificacion);
    }

    // GET
    @GetMapping
    public Object obtenerCalificaciones(

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityCalificacion
                .puedeVerCalificacion(usuario)){

            return "Acceso denegado";
        }

        return calificacionService.obtenerTodos();
    }

    // GET ID
    @GetMapping("/{id}")
    public Object buscarCalificacion(

            @PathVariable Long id,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityCalificacion
                .puedeVerCalificacion(usuario)){

            return "Acceso denegado";
        }

        return calificacionService.buscar(id);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String eliminarCalificacion(

            @PathVariable Long id,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityCalificacion
                .puedeEliminarCalificacion(usuario)){

            return "Acceso denegado";
        }

        boolean eliminado =
                calificacionService.eliminar(id);

        if(eliminado){

            return "Calificación eliminada";
        }

        return "Calificación no encontrada";
    }
}


