package com.beraca.DataEstructure;

import com.beraca.model.Usuario;
public class NodoUsuario {

        Usuario usuario;
        NodoUsuario siguiente;

        public NodoUsuario(Usuario usuario) {
            this.usuario = usuario;
            this.siguiente = null;
        }
    }

