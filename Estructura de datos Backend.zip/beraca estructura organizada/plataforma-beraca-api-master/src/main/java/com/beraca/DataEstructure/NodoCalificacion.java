package com.beraca.DataEstructure;

import com.beraca.model.Calificacion;

public class NodoCalificacion {

    Calificacion calificacion;
    NodoCalificacion siguiente;

    public NodoCalificacion(Calificacion calificacion) {
        this.calificacion = calificacion;
        this.siguiente = null;
    }
}