package com.beraca.DataEstructure;

import com.beraca.model.Calificacion;
import java.util.ArrayList;
import java.util.List;
public class ListaCalificacion {

        private NodoCalificacion cabeza;

        // AGREGAR
        public void agregar(Calificacion calificacion) {

            NodoCalificacion nuevo = new NodoCalificacion(calificacion);

            if(cabeza == null) {

                cabeza = nuevo;

            } else {

                NodoCalificacion actual = cabeza;

                while(actual.siguiente != null) {
                    actual = actual.siguiente;
                }

                actual.siguiente = nuevo;
            }
        }

        // LISTAR
        public List<Calificacion> listar() {

            List<Calificacion> calificaciones = new ArrayList<>();

            NodoCalificacion actual = cabeza;

            while(actual != null) {

                calificaciones.add(actual.calificacion);

                actual = actual.siguiente;
            }

            return calificaciones;
        }

        // BUSCAR POR ID
        public Calificacion buscar(Long id) {

            NodoCalificacion actual = cabeza;

            while(actual != null) {

                if(actual.calificacion.getID().equals(id)) {
                    return actual.calificacion;
                }

                actual = actual.siguiente;
            }

            return null;
        }

        // ELIMINAR
        public boolean eliminar(Long id) {

            if(cabeza == null) {
                return false;
            }

            if(cabeza.calificacion.getID().equals(id)) {
                cabeza = cabeza.siguiente;
                return true;
            }

            NodoCalificacion actual = cabeza;

            while(actual.siguiente != null) {

                if(actual.siguiente.calificacion.getID().equals(id)) {

                    actual.siguiente = actual.siguiente.siguiente;

                    return true;
                }

                actual = actual.siguiente;
            }

            return false;
        }
    }



