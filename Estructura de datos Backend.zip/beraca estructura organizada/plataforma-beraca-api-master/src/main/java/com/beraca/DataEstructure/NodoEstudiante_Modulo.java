package com.beraca.DataEstructure;

import com.beraca.model.Estudiante_Modulo;

public class NodoEstudiante_Modulo {

    Estudiante_Modulo estudiante_Modulo;

    NodoEstudiante_Modulo siguiente;

    public NodoEstudiante_Modulo(
            Estudiante_Modulo estudiante_Modulo) {

        this.estudiante_Modulo = estudiante_Modulo;

        this.siguiente = null;
    }
}