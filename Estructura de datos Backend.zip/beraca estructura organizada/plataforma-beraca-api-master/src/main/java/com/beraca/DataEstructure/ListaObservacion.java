package com.beraca.DataEstructure;

import com.beraca.model.Observacion;

import java.util.ArrayList;
import java.util.List;

public class ListaObservacion {

        private NodoObservacion cabeza;

        // AGREGAR
        public void agregar(Observacion observacion) {

            NodoObservacion nuevo = new NodoObservacion(observacion);

            if(cabeza == null) {

                cabeza = nuevo;

            } else {

                NodoObservacion actual = cabeza;

                while(actual.siguiente != null) {
                    actual = actual.siguiente;
                }

                actual.siguiente = nuevo;
            }
        }

        // LISTAR
        public List<Observacion> listar() {

            List<Observacion> observaciones = new ArrayList<>();

            NodoObservacion actual = cabeza;

            while(actual != null) {

                observaciones.add(actual.observacion);

                actual = actual.siguiente;
            }

            return observaciones;
        }

        // BUSCAR POR ID
        public Observacion buscar(Long id) {

            NodoObservacion actual = cabeza;

            while(actual != null) {

                if(actual.observacion.getID().equals(id)) {
                    return actual.observacion;
                }

                actual = actual.siguiente;
            }

            return null;
        }

        // ELIMINAR
        public boolean eliminar(Long id) {

            if(cabeza == null) {
                return false;
            }

            if(cabeza.observacion.getID().equals(id)) {
                cabeza = cabeza.siguiente;
                return true;
            }

            NodoObservacion actual = cabeza;

            while(actual.siguiente != null) {

                if(actual.siguiente.observacion.getID().equals(id)) {

                    actual.siguiente = actual.siguiente.siguiente;

                    return true;
                }

                actual = actual.siguiente;
            }

            return false;
        }
    }


