package com.beraca.Service;

import com.beraca.model.Usuario;
import org.springframework.stereotype.Service;
import com.beraca.DataEstructure.ListaUsuario;
import java.util.List;

@Service
public class UsuarioService {

    private ListaUsuario lista = new ListaUsuario();

    // POST
    public Usuario guardar(Usuario usuario) {

        lista.agregar(usuario);

        return usuario;
    }

    // GET
    public List<Usuario> obtenerTodos() {

        return lista.listar();
    }

    // GET ID
    public Usuario buscar(Long id) {

        return lista.buscar(id);
    }

    // DELETE
    public boolean eliminar(Long id) {

        return lista.eliminar(id);
    }
}
