package com.beraca.DataEstructure;

import com.beraca.model.Modulo;

public class NodoModulo {

    Modulo modulo;
    NodoModulo siguiente;

    public NodoModulo(Modulo modulo) {
        this.modulo = modulo;
        this.siguiente = null;
    }
}