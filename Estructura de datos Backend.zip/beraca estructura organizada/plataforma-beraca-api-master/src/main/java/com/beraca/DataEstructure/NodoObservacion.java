package com.beraca.DataEstructure;

import com.beraca.model.Observacion;

public class NodoObservacion {

    Observacion observacion;
    NodoObservacion siguiente;

    public NodoObservacion(Observacion observacion) {
        this.observacion = observacion;
        this.siguiente = null;
    }
}
