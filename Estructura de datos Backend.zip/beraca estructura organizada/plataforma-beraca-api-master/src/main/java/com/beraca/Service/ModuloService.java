package com.beraca.Service;

import com.beraca.DataEstructure.ListaModulo;
import com.beraca.model.Modulo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ModuloService {

        private ListaModulo lista = new ListaModulo();

        // POST
        public Modulo guardar(Modulo modulo) {

            lista.agregar(modulo);

            return modulo;
        }

        // GET
        public List<Modulo> obtenerTodos() {

            return lista.listar();
        }

        // GET ID
        public Modulo buscar(Long id) {

            return lista.buscar(id);
        }

        // DELETE
        public boolean eliminar(Long id) {

            return lista.eliminar(id);
        }
    }


