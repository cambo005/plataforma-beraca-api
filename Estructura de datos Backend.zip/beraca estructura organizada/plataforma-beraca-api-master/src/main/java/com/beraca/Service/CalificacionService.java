package com.beraca.Service;

import com.beraca.model.Calificacion;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CalificacionService {


        private ListaCalificacion lista = new ListaCalificacion();

        // POST
        public Calificacion guardar(Calificacion calificacion) {

            lista.agregar(calificacion);

            return calificacion;
        }

        // GET
        public List<Calificacion> obtenerTodos() {

            return lista.listar();
        }

        // GET ID
        public Calificacion buscar(Long id) {

            return lista.buscar(id);
        }

        // DELETE
        public boolean eliminar(Long id) {

            return lista.eliminar(id);
        }
    }



