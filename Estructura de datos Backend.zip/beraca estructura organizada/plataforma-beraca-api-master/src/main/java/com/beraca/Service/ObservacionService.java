package com.beraca.Service;

import com.beraca.DataEstructure.ListaObservacion;
import com.beraca.model.Observacion;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ObservacionService {

        private ListaObservacion lista = new ListaObservacion();

        // POST
        public Observacion guardar(Observacion observacion) {

            lista.agregar(observacion);

            return observacion;
        }

        // GET
        public List<Observacion> obtenerTodos() {

            return lista.listar();
        }

        // GET ID
        public Observacion buscar(Long id) {

            return lista.buscar(id);
        }

        // DELETE
        public boolean eliminar(Long id) {

            return lista.eliminar(id);
        }
    }

