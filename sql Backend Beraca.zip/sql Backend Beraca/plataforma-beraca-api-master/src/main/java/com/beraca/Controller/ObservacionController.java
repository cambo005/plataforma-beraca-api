package com.beraca.Controller;

import com.beraca.model.Observacion;
import com.beraca.model.Usuario;
import com.beraca.Security.SecurityObservacion;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/observaciones")
@CrossOrigin(origins = "*")
public class ObservacionController {

    // GET
    @GetMapping
    public String obtenerObservaciones(

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityObservacion
                .puedeVerObservacion(usuario)){

            return "Acceso denegado";
        }

        return "Lista de observaciones";
    }

    // POST
    @PostMapping("/crear")
    public Object crearObservacion(

            @RequestBody Observacion observacion,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityObservacion
                .puedeCrearObservacion(usuario)){

            return "Acceso denegado";
        }

        if(!SecurityObservacion
                .observacionValida(observacion)){

            return "Datos inválidos";
        }

        return observacion;
    }

    // PUT
    @PutMapping("/actualizar")
    public String actualizarObservacion(

            @RequestBody Observacion observacion,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityObservacion
                .puedeActualizarObservacion(usuario)){

            return "Acceso denegado";
        }

        return "Observación actualizada";
    }

    // DELETE
    @DeleteMapping("/eliminar/{id}")
    public String eliminarObservacion(

            @PathVariable Long id,

            @RequestParam String rol
    ) {

        Usuario usuario = new Usuario();
        usuario.setRol(rol);

        if(!SecurityObservacion
                .puedeEliminarObservacion(usuario)){

            return "Acceso denegado";
        }

        return "Observación eliminada con ID: " + id;
    }
}