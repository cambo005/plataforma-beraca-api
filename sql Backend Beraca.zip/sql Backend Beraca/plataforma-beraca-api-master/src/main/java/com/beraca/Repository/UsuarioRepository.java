package com.beraca.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.beraca.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario,Long>{
}