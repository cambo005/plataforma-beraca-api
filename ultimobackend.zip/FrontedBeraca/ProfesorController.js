// js/ProfesorController.js — VERSIÓN CORREGIDA
// Correcciones:
//   1. Comentarios individuales por corte (comentarioCorte1/2/3)
//   2. Mapeo correcto con la BD: comentario_corte1, comentario_corte2, comentario_corte3
//   3. Modal actualizado para mostrar 3 textareas separados

const API_BASE_URL = 'http://localhost:8080';
const ROL_PARAM = 'PROFESOR';

let listaEstudiantesGlobal = [];
let estudianteSeleccionado = null;

const MODULOS_DISPONIBLES = [
  "Ninguno asignado",
  "Módulo I - Vida Abundante",
  "Módulo II - Panorama Bíblico",
  "Módulo III - Campeones de la biblia",
  "Módulo IV - Escuela de líderes nivel 1",
  "Módulo IV - Escuela de líderes nivel 2",
];

document.addEventListener('DOMContentLoaded', () => {
  inicializarInterfaz();
  cargarEstudiantesDesdeBD();
});

function inicializarInterfaz() {
  const selectModulo = document.getElementById('selectModuloEstudiante');
  if (selectModulo) {
    selectModulo.innerHTML = '';
    MODULOS_DISPONIBLES.forEach(mod => {
      const opt = document.createElement('option');
      opt.value = mod;
      opt.textContent = mod;
      selectModulo.appendChild(opt);
    });
  }

  const buscador = document.getElementById('buscador');
  if (buscador) buscador.addEventListener('input', filtrarEstudiantes);

  const btnGuardar = document.getElementById('btnGuardarTodo');
  if (btnGuardar) btnGuardar.addEventListener('click', guardarHistorialAcademico);

  ['inputCorte1', 'inputCorte2', 'inputCorte3'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', calcularNotaFinalAutomatica);
  });
}

// =======================================================
// A. CARGA CRUZADA: USUARIOS + CALIFICACIONES + OBSERVACIONES
// =======================================================
async function cargarEstudiantesDesdeBD() {
  try {
    const [respuestaUsuarios, respuestaCalificaciones, respuestaObservaciones] = await Promise.all([
      fetch(`${API_BASE_URL}/usuarios`),
      fetch(`${API_BASE_URL}/calificaciones?rol=${ROL_PARAM}`),
      fetch(`${API_BASE_URL}/observaciones?rol=${ROL_PARAM}`)
    ]);

    if (!respuestaUsuarios.ok || !respuestaCalificaciones.ok) {
      throw new Error("Error al obtener las colecciones desde el servidor.");
    }

    const estudiantesBD      = await respuestaUsuarios.json();
    const calificacionesBD   = await respuestaCalificaciones.json();
    // Las observaciones son opcionales; si fallan no bloqueamos
    const observacionesBD    = respuestaObservaciones.ok ? await respuestaObservaciones.json() : [];

    listaEstudiantesGlobal = estudiantesBD.map(alumno => {
      const notaAsociada = Array.isArray(calificacionesBD)
        ? calificacionesBD.find(c => c.estudiante_id === alumno.id || c.estudianteId === alumno.id)
        : null;

      // ── Observaciones individuales por corte ──────────────────────────
      const obsAsociada = Array.isArray(observacionesBD)
        ? observacionesBD.find(o => o.estudiante_id === alumno.id || o.estudianteId === alumno.id)
        : null;

      let moduloNombreVisual = "Ninguno asignado";
      if (notaAsociada) {
        const idMod = notaAsociada.modulo_id ?? notaAsociada.moduloId;
        moduloNombreVisual = MODULOS_DISPONIBLES[idMod] || `Módulo #${idMod}`;
      }

      return {
        id:           alumno.id,
        nombre:       alumno.nombre || `Estudiante #${alumno.id}`,
        codigo:       alumno.correo  || `EST-${alumno.id}`,
        modulo:       moduloNombreVisual,
        corte1:       notaAsociada?.corte1    ?? "0.0",
        corte2:       notaAsociada?.corte2    ?? "0.0",
        corte3:       notaAsociada?.corte3    ?? "0.0",
        notaFinal:    notaAsociada?.notaFinal ?? notaAsociada?.nota_final ?? "0.0",
        // ── Comentarios individuales (mapeados desde columnas reales de la BD) ──
        comentarioCorte1: obsAsociada?.comentario_corte1 ?? obsAsociada?.comentarioCorte1 ?? "",
        comentarioCorte2: obsAsociada?.comentario_corte2 ?? obsAsociada?.comentarioCorte2 ?? "",
        comentarioCorte3: obsAsociada?.comentario_corte3 ?? obsAsociada?.comentarioCorte3 ?? "",
        calificacionId: notaAsociada?.id  ?? null,
        observacionId:  obsAsociada?.id   ?? null,
      };
    });

    renderizarTarjetasEstudiantes(listaEstudiantesGlobal);
  } catch (error) {
    console.error("Error al conectar e integrar datos en tiempo real:", error);
    listaEstudiantesGlobal = [];
    renderizarTarjetasEstudiantes(listaEstudiantesGlobal);
  }
}

// =======================================================
// B. RENDERIZADO DE TARJETAS
// =======================================================
function renderizarTarjetasEstudiantes(estudiantes) {
  const listaCardsContainer = document.getElementById('listaCards');
  const conteoText          = document.getElementById('conteo');
  if (!listaCardsContainer) return;

  listaCardsContainer.innerHTML = '';
  if (conteoText) conteoText.textContent = `${estudiantes.length} estudiante${estudiantes.length !== 1 ? 's' : ''}`;

  if (estudiantes.length === 0) {
    listaCardsContainer.innerHTML = `<p style="grid-column:1/-1;text-align:center;color:#888;margin-top:20px;">No se encontraron estudiantes registrados.</p>`;
    return;
  }

  estudiantes.forEach(estudiante => {
    const card = document.createElement('div');
    card.className = 'stu-card';
    card.addEventListener('click', () => abrirModalPerfilEstudiante(estudiante));
    card.innerHTML = `
      <div class="stu-card-top">
        <div class="stu-avatar"><i class="bi bi-person-fill"></i></div>
        <h4>${estudiante.nombre}</h4>
        <div class="stu-code">Código: ${estudiante.codigo}</div>
      </div>
      <div class="stu-card-bottom">
        <div class="modulo-tag">Mod: <strong>${estudiante.modulo}</strong></div>
        <span class="badge-estado badge-activo">Activo</span>
      </div>`;
    listaCardsContainer.appendChild(card);
  });
}

// =======================================================
// C. FILTRADO
// =======================================================
function filtrarEstudiantes() {
  const t = document.getElementById('buscador').value.toLowerCase().trim();
  renderizarTarjetasEstudiantes(
    listaEstudiantesGlobal.filter(e =>
      e.nombre?.toLowerCase().includes(t) || e.codigo?.toLowerCase().includes(t)
    )
  );
}

// =======================================================
// D. ABRIR MODAL — ahora carga los 3 comentarios por separado
// =======================================================
function abrirModalPerfilEstudiante(estudiante) {
  estudianteSeleccionado = estudiante;

  document.getElementById('perfilNombre').textContent = estudiante.nombre;
  document.getElementById('perfilCodigo').textContent = `Código/ID: ${estudiante.codigo}`;
  document.getElementById('selectModuloEstudiante').value = estudiante.modulo;

  document.getElementById('inputCorte1').value = estudiante.corte1;
  document.getElementById('inputCorte2').value = estudiante.corte2;
  document.getElementById('inputCorte3').value = estudiante.corte3;
  document.getElementById('inputNotaFinal').value = estudiante.notaFinal;

  // ── Comentarios individuales ──────────────────────────────────────────
  document.getElementById('comentarioCorte1').value = estudiante.comentarioCorte1 || '';
  document.getElementById('comentarioCorte2').value = estudiante.comentarioCorte2 || '';
  document.getElementById('comentarioCorte3').value = estudiante.comentarioCorte3 || '';

  document.getElementById('perfilOverlay').classList.add('open');
}

function calcularNotaFinalAutomatica() {
  const c1 = parseFloat(document.getElementById('inputCorte1').value) || 0;
  const c2 = parseFloat(document.getElementById('inputCorte2').value) || 0;
  const c3 = parseFloat(document.getElementById('inputCorte3').value) || 0;
  document.getElementById('inputNotaFinal').value = ((c1 + c2 + c3) / 3).toFixed(1);
}

// =======================================================
// E. GUARDAR — envía comentario_corte1/2/3 al backend
// =======================================================
async function guardarHistorialAcademico() {
  if (!estudianteSeleccionado) return;

  const corte1Str    = document.getElementById('inputCorte1').value    || "0.0";
  const corte2Str    = document.getElementById('inputCorte2').value    || "0.0";
  const corte3Str    = document.getElementById('inputCorte3').value    || "0.0";
  const notaFinalStr = document.getElementById('inputNotaFinal').value || "0.0";

  // ── Leer los 3 comentarios individualmente ───────────────────────────
  const comentarioC1 = document.getElementById('comentarioCorte1').value.trim();
  const comentarioC2 = document.getElementById('comentarioCorte2').value.trim();
  const comentarioC3 = document.getElementById('comentarioCorte3').value.trim();

  const selectModElem  = document.getElementById('selectModuloEstudiante');
  const moduloIdNumerico = selectModElem ? Math.max(1, selectModElem.selectedIndex) : 1;

  const modeloCalificacion = {
    id:            estudianteSeleccionado.calificacionId || null,
    // Ambas versiones: camelCase (Jackson default) y snake_case (naming strategy)
    estudianteId:  estudianteSeleccionado.id,
    estudiante_id: estudianteSeleccionado.id,
    moduloId:      moduloIdNumerico,
    modulo_id:     moduloIdNumerico,
    corte1:        corte1Str,
    corte2:        corte2Str,
    corte3:        corte3Str,
    notaFinal:     notaFinalStr,
    nota_final:    notaFinalStr,
  };

  try {
    const peticiones = [];

    // PETICIÓN A: Calificaciones
    peticiones.push(
      fetch(`${API_BASE_URL}/calificaciones/crear?rol=${ROL_PARAM}`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(modeloCalificacion),
      }).then(r => r.json().catch(() => r.text()))
    );

    // PETICIÓN B: Observaciones
    // Se envían AMBAS versiones del nombre (camelCase para Jackson/Spring,
    // snake_case como fallback) para no depender de la configuración del backend.
    const modeloObservacion = {
      id:                  estudianteSeleccionado.observacionId || null,
      // camelCase — lo que Spring/Jackson espera por defecto en la entidad Java
      estudianteId:        estudianteSeleccionado.id,
      moduloId:            moduloIdNumerico,
      comentarioCorte1:    comentarioC1,
      comentarioCorte2:    comentarioC2,
      comentarioCorte3:    comentarioC3,
      // snake_case — fallback por si el backend tiene naming_strategy configurado
      estudiante_id:       estudianteSeleccionado.id,
      modulo_id:           moduloIdNumerico,
      comentario_corte1:   comentarioC1,
      comentario_corte2:   comentarioC2,
      comentario_corte3:   comentarioC3,
      fecha:               new Date().toISOString().split('T')[0],
    };

    peticiones.push(
      fetch(`${API_BASE_URL}/observaciones/crear?rol=${ROL_PARAM}`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(modeloObservacion),
      }).then(r => r.json().catch(() => r.text()))
    );

    const respuestas = await Promise.all(peticiones);

    if (respuestas.some(r => r === "Acceso denegado" || r === "Datos inválidos")) {
      alert("Error: Datos inválidos o acceso denegado por el controlador.");
      return;
    }

    alert(`¡Cambios de ${estudianteSeleccionado.nombre} guardados exitosamente!`);
    document.getElementById('perfilOverlay').classList.remove('open');
    cargarEstudiantesDesdeBD();

  } catch (error) {
    console.error("Error al guardar:", error);
    alert("Error de red al intentar conectar con el servidor.");
  }
}

// --- MODALES ---
window.cerrarPerfil = function(e) {
  if (e.target.id === 'perfilOverlay') {
    document.getElementById('perfilOverlay').classList.remove('open');
  }
};

window.toggleDropdown = function(e) {
  e.stopPropagation();
  document.getElementById('modulosDropdown').classList.toggle('open');
};

document.addEventListener('click', () => {
  document.getElementById('modulosDropdown')?.classList.remove('open');
});