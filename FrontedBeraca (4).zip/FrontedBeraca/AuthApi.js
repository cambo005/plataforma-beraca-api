// AuthApi.js
const BASE_URL = "http://localhost:8080";

/**
 * Envía los datos de inicio de sesión unificados al backend
 * @param {Object} datosUsuario - Objeto con los atributos { correo, password } o { nombre, password }
 */
export const loginAPI = async (datosUsuario) => {
    try {
        const response = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(datosUsuario)
        });

        // Como tu AuthController devuelve un String plano ("Acceso profesor", "Datos incompletos", etc.)
        // procesamos la respuesta con .text() en lugar de .json()
        const resultadoTexto = await response.text();
        return resultadoTexto;
        
    } catch (error) {
        console.error("Error en la conexión con el servidor:", error);
        throw error;
    }
};